//package org.example.shopxVendor.model;
//
//public class VendorSubscriptionModel {
//    private String varificationStatus;
//
//    public String getCompanyName() {
//        return varificationStatus;
//    }
//
//    public void setCompanyName(String companyName) {
//        this.varificationStatus = companyName;
//    }
//
//}
